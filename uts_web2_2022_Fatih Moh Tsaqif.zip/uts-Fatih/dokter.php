<?php

class Dokter
{
  private $servername = 'localhost';
  private $username = 'root';
  private $password = 'root';
  private $database = 'utsumar';
  public $con;

  // Database Connrction
  public function __construct()
  {
    $this->con = new mysqli($this->servername, $this->username, $this->password, $this->database);
    if (mysqli_connect_error()) {
      trigger_error('Failed to connect to MySQL:' . mysqli_connect_error());
    } else {
      return $this->con;
    }
  }

  // Insert Data into dokter table
  public function insertDokter($post)
  {
    $nip = $this->con->real_escape_string($_POST['nip']);
    $nama_lengkap = $this->con->real_escape_string($_POST['nama_lengkap']);
    $spesialis = $this->con->real_escape_string($_POST['spesialis']);
    $tempat_praktek = $this->con->real_escape_string($_POST['tempat_praktek']);
    $query = "INSERT INTO dokter(nip,nama_lengkap,spesialis,tempat_praktek) VALUES('$nip','$nama_lengkap','$spesialis','$tempat_praktek')";
    $sql = $this->con->query($query);
    print_r($nip);
    if ($sql == true) {
      header('Location:index.php?msg1=insert');
    } else {
      echo 'Registrasi Dokter Gagal. Silahkan coba lagi';
    }
  }

  // Get all Dokter
  public function getDokter()
  {
    $query = "SELECT * FROM dokter";
    $result = $this->con->query($query);
    if ($result->num_rows > 0) {
      $data = array();
      while ($row = $result->fetch_assoc()) {
        $data[] = $row;
      }
      return $data;
    } else {
      echo 'No found records';
    }
  }

  public function getDokterById($id)
  {
    $query = "SELECT * FROM dokter WHERE iddokter ='$id' ";
    $result = $this->con->query($query);

    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      return $row;
    } else {
      echo 'Data dokter tidak ditemukan';
    }
  }


  public function updateDokter($postData)
  {
    $nip = $this->con->real_escape_string($_POST['nip']);
    $nama_lengkap = $this->con->real_escape_string($_POST['nama_lengkap']);
    $spesialis = $this->con->real_escape_string($_POST['spesialis']);
    $tempat_praktek = $this->con->real_escape_string($_POST['tempat_praktek']);
    $id = $this->con->real_escape_string($_POST['iddokter']);

    if (!empty($id) && !empty($postData)) {
      $query = "UPDATE dokter SET nip = '$nip', nama_lengkap = '$nama_lengkap', spesialis = '$spesialis', tempat_praktek = '$tempat_praktek' WHERE iddokter = '$id'";
      $sql = $this->con->query($query);
      if ($sql == true) {
        header('Location:index.php?msg2=update');
      } else {
        echo 'Update data gagal';
      }
    }
  }

  public function deleteDokter($id)
  { {
      $query = "DELETE FROM dokter WHERE iddokter = '$id'";
      $sql = $this->con->query($query);
      if ($sql == true) {
        header("Location:index.php?msg3=delete");
      } else {
        echo "Record does not delete try again";
      }
    }
  }

  public function searchDokter($nip)
  {
    $query = "SELECT * FROM dokter WHERE nip LIKE '%$nip%'";
    $result = $this->con->query($query);
    if ($result->num_rows > 0) {
      $data = array();
      while ($row = $result->fetch_assoc()) {
        $data[] = $row;
      }
      return $data;
    } else {
      echo 'No found records';
    }
  }
}

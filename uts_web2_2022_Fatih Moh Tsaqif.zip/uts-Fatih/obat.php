<?php

class Obat
{
  private $servername = 'localhost';
  private $username = 'root';
  private $password = 'root';
  private $database = 'utsumar';
  public $con;

  // Database Connrction
  public function __construct()
  {
    $this->con = new mysqli($this->servername, $this->username, $this->password, $this->database);
    if (mysqli_connect_error()) {
      trigger_error('Failed to connect to MySQL:' . mysqli_connect_error());
    } else {
      return $this->con;
    }
  }

  // Insert Data into obat table
  public function insertObat($post)
  {
    $kode_obat = $this->con->real_escape_string($_POST['kode_obat']);
    $nama_obat = $this->con->real_escape_string($_POST['nama_obat']);
    $bentuk = $this->con->real_escape_string($_POST['bentuk']);
    $berat = $this->con->real_escape_string($_POST['berat']);
    $query = "INSERT INTO obat(kode_obat,nama_obat,bentuk,berat) VALUES('$kode_obat','$nama_obat','$bentuk','$berat')";
    $sql = $this->con->query($query);
    print_r($kode_obat);
    if ($sql == true) {
      header('Location:index.php?msg1=insert');
    } else {
      echo 'Registrasi Obat Gagal. Silahkan coba lagi';
    }
  }

  // Get all obat
  public function getObat()
  {
    $query = "SELECT * FROM obat";
    $result = $this->con->query($query);
    if ($result->num_rows > 0) {
      $data = array();
      while ($row = $result->fetch_assoc()) {
        $data[] = $row;
      }
      return $data;
    } else {
      echo 'No found records';
    }
  }

  public function getObatById($id)
  {
    $query = "SELECT * FROM obat WHERE idobat ='$id' ";
    $result = $this->con->query($query);

    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      return $row;
    } else {
      echo 'Data Obat tidak ditemukan';
    }
  }


  public function updateObat($postData)
  {
    $kode_obat = $this->con->real_escape_string($_POST['kode_obat']);
    $nama_obat = $this->con->real_escape_string($_POST['nama_obat']);
    $bentuk = $this->con->real_escape_string($_POST['bentuk']);
    $berat = $this->con->real_escape_string($_POST['berat']);
    $id = $this->con->real_escape_string($_POST['idobat']);

    if (!empty($id) && !empty($postData)) {
      $query = "UPDATE obat SET kode_obat = '$kode_obat', nama_obat = '$nama_obat', bentuk = '$bentuk', berat = '$berat' WHERE idobat = '$id'";
      $sql = $this->con->query($query);
      if ($sql == true) {
        header('Location:index.php?msg2=update');
      } else {
        echo 'Update data gagal';
      }
    }
  }

  public function deleteObat($id)
  { {
      $query = "DELETE FROM obat WHERE idobat = '$id'";
      $sql = $this->con->query($query);
      if ($sql == true) {
        header("Location:index.php?msg3=delete");
      } else {
        echo "Record does not delete try again";
      }
    }
  }

  public function searchObat($kode_obat)
  {
    $query = "SELECT * FROM obat WHERE kode_obat LIKE '%$kode_obat%'";
    $result = $this->con->query($query);
    if ($result->num_rows > 0) {
      $data = array();
      while ($row = $result->fetch_assoc()) {
        $data[] = $row;
      }
      return $data;
    } else {
      echo 'No found records';
    }
  }
}

<?php

// Include database file
include '../obat.php';
$obatObj = new Obat();
// Delete record from table
if (isset($_GET['deleteId']) && !empty($_GET['deleteId'])) {
  $deleteId = $_GET['deleteId'];
  $obatObj->deleteObat($deleteId);
}

if (isset($_GET['cari'])) {
  $cari = $_GET['cari'];
  $obat = $obatObj->searchObat($cari);
} else {
  $obat = $obatObj->getObat();
}

?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
  <title>Hello, world!</title>
</head>

<body>

  <nav class="navbar navbar-expand-lg bg-primary ">
    <div class="container container-fluid">
      <a class="navbar-brand text-white" href="#">Umar Klinik</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse " id="navbarNav">
        <ul class="navbar-nav text-white">
          <li class="nav-item">
            <a class="nav-link text-white" href="/php-native/uts-umar/dokter/index.php">Dokter</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="/php-native/uts-umar/obat/index.php">Obat</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="/php-native/uts-umar/pasien/index.php">Pasien</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container p-3">
    <?php
    if (isset($_GET['msg1']) == "insert") {
      echo "<div class='alert alert-success alert-dismissible'>
             
              Your Registration added successfully
            </div>";
    }
    if (isset($_GET['msg2']) == "update") {
      echo "<div class='alert alert-success alert-dismissible'>
             
              Your Registration updated successfully
            </div>";
    }
    if (isset($_GET['msg3']) == "delete") {
      echo "<div class='alert alert-success alert-dismissible'>
             
              Record deleted successfully
            </div>";
    }
    ?>
    <div class="text-center">
      <h1>Data Obat</h1>
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <div class="row">
          <div class="col-lg-6">
            <form action="index.php" method="get">
              <label>Cari :</label>
              <input type="text" name="cari">
              <input class="btn btn-primary" type="submit" value="Cari">
            </form>
          </div>
          <div class="col-lg-6">
            <div class="text-end">
              <a href="add.php" class="btn btn-primary">Tambah Obat</a>
            </div>
          </div>
        </div>

        <table class="table table-hover">
          <thead>
            <tr>
              <th>No</th>
              <th>Kode Obat</th>
              <th>Nama Obat</th>
              <th>Bentuk</th>
              <th>Berat</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $i = 1;
            foreach ($obat as $obt) {;
            ?>
              <tr>
                <td><?= $i++ ?></td>
                <td><?= $obt['kode_obat'] ?></td>
                <td><?= $obt['nama_obat'] ?></td>
                <td><?= $obt['bentuk'] ?></td>
                <td><?= $obt['berat'] ?></td>
                <td>
                  <button class="btn btn-primary mr-2"><a href="edit.php?editId=<?= $obt['idobat'] ?>">
                      <i class="fa fa-pencil text-white" aria-hidden="true"></i></a></button>
                  <button class="btn btn-danger"><a href="index.php?deleteId=<?= $obt['idobat'] ?>" onclick="confirm('Are you sure want to delete this record')">
                      <i class="fa fa-trash text-white" aria-hidden="true"></i>
                    </a></button>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
</body>

</html>
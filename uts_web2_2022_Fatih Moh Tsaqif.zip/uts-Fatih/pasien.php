<?php

class Pasien
{
  private $servername = 'localhost';
  private $username = 'root';
  private $password = 'root';
  private $database = 'utsumar';
  public $con;

  // Database Connrction
  public function __construct()
  {
    $this->con = new mysqli($this->servername, $this->username, $this->password, $this->database);
    if (mysqli_connect_error()) {
      trigger_error('Failed to connect to MySQL:' . mysqli_connect_error());
    } else {
      return $this->con;
    }
  }

  // Insert Data into pasien table
  public function insertPasien($post)
  {
    $nomor_pasien = $this->con->real_escape_string($_POST['nomor_pasien']);
    $nama_lengkap = $this->con->real_escape_string($_POST['nama_lengkap']);
    $jenis_kelamin = $this->con->real_escape_string($_POST['jenis_kelamin']);
    $umur = $this->con->real_escape_string($_POST['umur']);
    $query = "INSERT INTO pasien(nomor_pasien,nama_lengkap,jenis_kelamin,umur) VALUES('$nomor_pasien','$nama_lengkap','$jenis_kelamin','$umur')";
    $sql = $this->con->query($query);
    print_r($nomor_pasien);
    if ($sql == true) {
      header('Location:index.php?msg1=insert');
    } else {
      echo 'Registrasi Pasien Gagal. Silahkan coba lagi';
    }
  }

  // Get all pasien
  public function getPasien()
  {
    $query = "SELECT * FROM pasien";
    $result = $this->con->query($query);
    if ($result->num_rows > 0) {
      $data = array();
      while ($row = $result->fetch_assoc()) {
        $data[] = $row;
      }
      return $data;
    } else {
      echo 'No found records';
    }
  }

  public function getPasienById($id)
  {
    $query = "SELECT * FROM pasien WHERE idpasien ='$id' ";
    $result = $this->con->query($query);

    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      return $row;
    } else {
      echo 'Data Pasien tidak ditemukan';
    }
  }


  public function updatePasien($postData)
  {
    $nomor_pasien = $this->con->real_escape_string($_POST['nomor_pasien']);
    $nama_lengkap = $this->con->real_escape_string($_POST['nama_lengkap']);
    $jenis_kelamin = $this->con->real_escape_string($_POST['jenis_kelamin']);
    $umur = $this->con->real_escape_string($_POST['umur']);
    $id = $this->con->real_escape_string($_POST['idpasien']);

    if (!empty($id) && !empty($postData)) {
      $query = "UPDATE pasien SET nomor_pasien = '$nomor_pasien', nama_lengkap = '$nama_lengkap', jenis_kelamin = '$jenis_kelamin', umur = '$umur' WHERE idpasien = '$id'";
      $sql = $this->con->query($query);
      if ($sql == true) {
        header('Location:index.php?msg2=update');
      } else {
        echo 'Update data gagal';
      }
    }
  }

  public function deletePasien($id)
  { {
      $query = "DELETE FROM pasien WHERE idpasien = '$id'";
      $sql = $this->con->query($query);
      if ($sql == true) {
        header("Location:index.php?msg3=delete");
      } else {
        echo "Record does not delete try again";
      }
    }
  }

  public function searchPasien($nomor_pasien)
  {
    $query = "SELECT * FROM pasien WHERE nomor_pasien LIKE '%$nomor_pasien%'";
    $result = $this->con->query($query);
    if ($result->num_rows > 0) {
      $data = array();
      while ($row = $result->fetch_assoc()) {
        $data[] = $row;
      }
      return $data;
    } else {
      echo 'No found records';
    }
  }
}
